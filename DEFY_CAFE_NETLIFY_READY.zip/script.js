document.addEventListener("DOMContentLoaded",()=>{document.body.classList.add("loaded");});
document.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>a.style.opacity=".75"));
